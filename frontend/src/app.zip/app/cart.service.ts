import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  private serviceURL:any = "http://localhost:5001/cart/getAllCarts";

  private postURL:any = "http://localhost:5001/cart/register";
  
  private updateURL:any = "http://localhost:5001/cart/updateCart";

  private deleteURL:any = "http://localhost:5001/cart/delete";

  flag:number;

  public cart:any = [];
  public qty:any = [];
  public price:any = [];
  public cost:any = [];
  public toppings:any = [];

  constructor(private httpClient:HttpClient) { }

  getCartItems(data)
  {
    console.log('Inside getCartItems in cart.service ',data);
    return this.httpClient.post(this.serviceURL,data)
    .subscribe((data:any)=>{
      this.cart = data.data;
      // console.log('cart length is '+this.cart.length);
      // console.log(this.cart);
      if(this.cart.length>0)
      {
        console.log('Inside if');
        for(var i:number =0;i<this.cart.length;i++)
        {
          this.qty[i] = this.cart[i].quantity;
          this.cost[i] = this.cart[i].price;
          this.price[i] = this.qty[i]*this.cost[i];
          var obj:any = {};
          for(var j:number = 0;j<this.cart[i].topping.length;j++){
              var temp = this.cart[i].topping[j];
              var quan = this.cart[i].topping_quantity[j];
              obj.topping = temp;
              obj.quantity = quan;
              this.toppings.push(obj);
          }
          // console.log(this.qty[i]);
          // console.log(this.cost[i]);
          // console.log(this.price[i]);
        }
      }
    })
  }

  getQty()
  {
    return this.qty;
  }

  getPrice()
  {
    return this.price;
  }

  getCost()
  {
    return this.cost;
  }

  getCart()
  {
    return this.cart;
  }

  getToppings()
  {
    return this.toppings;
  }
    

  addToCart(data)
  {
    console.log('inside addToCart method in cart.service.ts')
    this.httpClient.post(this.postURL,data)
    .subscribe((data:any)=>{
      console.log("Added to Cart ",data);
      if(data.message=='Cart Registered')
        this.flag=1;
      else if(data.message=='Cart Item Updated')
        this.flag=2;
      else 
        this.flag=0;
    })

  }

  getFlag():number{
    console.log('Flag valye in cart.service' + this.flag)
    return this.flag;
  }

  update(data)
  {
    this.httpClient.post(this.updateURL,data)
    .subscribe((data)=>{
      console.log('Update Success');
    })
  }

  delete(data)
  {
    this.httpClient.post(this.deleteURL,data)
    .subscribe((data)=>{
      console.log('Delete method in cart.service, data received is ',data);
    })
  }
}
