import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class IngredientService {

  private postURL:any = "http://localhost:5001/ingredient/getIngredientPrice";

  price:any;

  constructor(private httpClient:HttpClient) { }

  getIngredientPrice(data){
    this.httpClient.post(this.postURL,data)
    .subscribe((data:any)=>{
      console.log('Delete method in cart.service, data received is ',data);
      this.price = data.price;
    })
  }

  getPrice()
  {
    return this.price;
  }
}
